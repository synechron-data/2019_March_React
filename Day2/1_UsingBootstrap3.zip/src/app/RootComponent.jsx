import React from 'react';

import ComponentOne from "./ComponentOne";
import ComponentTwo from "./ComponentTwo";

class RootComponent extends React.Component {
    render() {
        return (
            <div className="container">
                <h1 className="text-info">Hello from Root Component</h1>
                <ComponentOne/>
                <ComponentTwo/>
            </div>
        );
    }
}

export default RootComponent;