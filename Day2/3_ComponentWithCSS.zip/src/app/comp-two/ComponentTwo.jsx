import React from 'react';

import './ComponentTwo.css';

class ComponentTwo extends React.Component {
    render() {
        return (
            <h2 className="text-success card2">Hello from Component Two!</h2>
        );
    }
}

export default ComponentTwo;

// import React from 'react';

// class ComponentTwo extends React.Component {
//     render() {
//         const card2 = {
//             margin: '1em',
//             paddingLeft: 0,
//             border: '2px dashed green'
//         };

//         return (
//             <h2 style={card2} className="text-success">Hello from Component Two!</h2>
//         );
//     }
// }

// export default ComponentTwo;