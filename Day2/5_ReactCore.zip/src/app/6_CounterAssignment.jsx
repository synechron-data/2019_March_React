import React, { Component } from 'react';

class Counter extends Component {
    constructor(props) {
        super(props);
        this.state = { count: 0, flag: false, clickCount: 0 };
        this.inc = this.inc.bind(this);
        this.dec = this.dec.bind(this);
        this.reset = this.reset.bind(this);
    }

    manageClickCount() {
        this.setState({ clickCount: this.state.clickCount + 1 }, () => {
            if (this.state.clickCount > 9) {
                this.setState({ flag: true }, () => {
                    this.props.onMax(this.state.flag);
                });
            }
        });
    }

    inc(e) {
        this.setState({ count: this.state.count + this.props.interval }, () => {
            this.manageClickCount();
        });
    }

    dec(e) {
        this.setState({ count: this.state.count - this.props.interval }, () => {
            this.manageClickCount();
        });
    }

    reset(e) {
        this.setState({ count: 0, flag: false, clickCount: 0 }, () => {
            this.props.onMax(this.state.flag);
        });
    }

    render() {
        return (
            <div className="row">
                <div className="row">
                    {this.props.children}
                </div>
                <div className="row">
                    <div className="col-sm-4">
                        <input type="text" className="form-control" value={this.state.count} readOnly />
                    </div>
                    <div className="col-sm-1">
                        <button className="btn btn-info btn-block"
                            onClick={this.inc} disabled={this.state.flag}>+</button>
                    </div>
                    <div className="col-sm-1">
                        <button className="btn btn-info btn-block"
                            onClick={this.dec} disabled={this.state.flag}>-</button>
                    </div>
                    <div className="col-sm-2">
                        <button className="btn btn-info btn-block"
                            onClick={this.reset} disabled={!this.state.flag}>Reset</button>
                    </div>
                </div>
            </div>
        );
    }

    // static get defaultProps() {
    //     return {
    //         interval: 1
    //     };
    // }
}

Counter.defaultProps = {
    interval: 1
};

class CounterAssignment extends Component {
    constructor(props) {
        super(props);
        this.state = { message: "" };
        this.p_reset = this.p_reset.bind(this);
        this.updateMessage = this.updateMessage.bind(this);
        this.childRef = React.createRef();
    }

    p_reset(e) {
        // console.log(this.childRef);
        this.childRef.current.reset(e);
    }

    updateMessage(flag) {
        if (flag) {
            this.setState({ message: "Max Click Reached, click Reset..." })
        } else {
            this.setState({ message: "" })
        }
    }

    render() {
        return (
            <div>
                <h2 className="alert alert-danger">{this.state.message}</h2>
                <Counter ref={this.childRef} onMax={this.updateMessage}>
                    <h2>Counter with default interval</h2>
                </Counter>
                <br />
                <div className="col-sm-2">
                    <button className="btn btn-warning btn-block" onClick={this.p_reset}>Parent Reset</button>
                </div>

                {/* <Counter interval={10}>
                    <h2>Counter with interval as 10</h2>
                </Counter> */}
            </div>
        );
    }
}

export default CounterAssignment;