import React, { Component } from 'react';

class Button extends Component {
    constructor(props) {
        super(props);
    }

    handleClick(){
        alert("Hello, Button is clicked");
    }

    render() {
        return (
            <button className="btn btn-info" onClick={this.handleClick}>Click Me</button>
        );
    }
}

export default Button;