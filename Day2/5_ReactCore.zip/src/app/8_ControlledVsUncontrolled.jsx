import React, { Component } from 'react';

class ControlledVsUncontrolled extends Component {
    constructor(props) {
        super(props);
        this.state = { name: "Manish" };
        this.handleClick = this.handleClick.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(e) {
        this.setState({ name: e.target.value });
    }

    handleClick(e) {
        this.setState({ name: this.refs.t1.value });
    }

    render() {
        return (
            <div>
                <input type="text" value="Abhijeet" readOnly />

                <input type="text" value={this.state.name} readOnly />

                <input type="text" defaultValue={this.state.name} />

                <input type="text" value={this.state.name} onChange={this.handleChange} />

                <h3 className="text-info">{this.state.name}</h3>

                <input type="text" ref="t1" />
                <br />
                <button onClick={this.handleClick}>Click</button>
            </div>
        );
    }
}

export default ControlledVsUncontrolled;