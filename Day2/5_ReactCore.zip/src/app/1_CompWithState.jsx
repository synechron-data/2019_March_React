import React, { Component } from 'react';

class ComponentWithState extends Component {
    constructor() {
        super();
        this.state = new Date();
        this.state = { name: "Synechron" };
    }

    render() {
        return (
            <h2 className="text-info">Hello, {this.state.name}</h2>
        );
    }
}

export default ComponentWithState;