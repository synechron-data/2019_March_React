import React, { Component } from 'react';

class StateChangeComponent extends Component {
    constructor(props) {
        super(props);
        // this.state = { count: 0 };
        this.state = { count: this.props.data, id: 1 };

    }

    handleClick() {
        // console.log(this);
        // this.state.count += 1;
        // console.log(this.state);
        // this.setState({ count: this.state.count + 1 });
        // // this.props.data = 100;
        // console.log(this.state);
        this.setState({ count: this.state.count + 1 }, () => {
            console.log(this.state);
        });
    }

    render() {
        return (
            <React.Fragment>
                <h2 className="text-info">Id: {this.state.id}</h2>
                <h2 className="text-info">Count: {this.state.count}</h2>
                {/* <button className="btn btn-info" onClick={this.handleClick.bind(this)}>Click Me</button> */}
                <button className="btn btn-info" onClick={this.handleClick.bind(this)}>Count: {this.state.count}</button>
            </React.Fragment>
        );
    }
}

export default StateChangeComponent;