import React from 'react';
import ComponentWithState from './1_CompWithState';
import ComponentWithProps from './2_CompWithProps';
import Button from './3_CompWithBehavior';
import StateChangeComponent from './4_StateChange';
import EventComponent from './5_ReactEvent';
import CounterAssignment from './6_CounterAssignment';
import AssignmentRoot from './7_Assignment';
import ControlledVsUncontrolled from './8_ControlledVsUncontrolled';
import CalculatorAssignment from './9_CalculatorAssignment';

class RootComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = { data: 12 };
    }

    check() {

    }

    render() {
        const address = { city: "Pune", pin: 411021 };
        return (
            <div className="container">
                {/* <h2 className="text-info">Data: {this.state.data}</h2> */}
                {/* <ComponentWithState/> */}
                {/* <ComponentWithProps ename={"Manish"} age={30} add={address} display={this.check}/> */}
                {/* <Button /> */}
                {/* <StateChangeComponent data={this.state.data} /> */}
                {/* <EventComponent/> */}
                {/* <CounterAssignment/> */}
                {/* <AssignmentRoot/> */}
                {/* <ControlledVsUncontrolled/> */}
                <CalculatorAssignment/>
            </div>
        );
    }
}

export default RootComponent;