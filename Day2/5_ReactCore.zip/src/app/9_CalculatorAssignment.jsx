import React, { Component } from 'react';

class CalculatorOne extends Component {
    constructor(props) {
        super(props);
        this.state = { data: { t1: 0, t2: 0 }, result: 0 };
    }

    render() {
        return (
            <form className="form-horizontal" >
                <fieldset>
                    <legend>Calculator Assignment</legend>
                    <div className="form-group">
                        <label className="control-label col-sm-2" htmlFor="t1">Number One</label>
                        <div className="col-sm-6">
                            <input type="text" className="form-control" id="t1" />
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-2" htmlFor="t2">Number Two</label>
                        <div className="col-sm-6">
                            <input type="text" className="form-control" id="t2" />
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="col-sm-6 col-sm-offset-2">
                            <h3>Result: {this.state.result}</h3>
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="col-sm-offset-2 col-sm-3">
                            <button type="submit" className="btn btn-success btn-block">Add</button>
                        </div>
                        <div className="col-sm-3">
                            <button type="reset" className="btn btn-primary btn-block">Reset</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        );
    }
}


class CalculatorAssignment extends Component {
    render() {
        return (
            <div>
                <CalculatorOne />
            </div>
        );
    }
}

export default CalculatorAssignment;