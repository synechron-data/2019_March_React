import React, { Component } from 'react';

class ComponentWithProps extends Component {
    constructor(props) {
        super(props);
        // console.log("State: ", this.state);
        console.log("Props: ", this.props);
        // console.log(typeof this.props.ename);
        // console.log(typeof this.props.age);
    }

    render() {
        return (
            <h2 className="text-info">Hello, </h2>
        );
    }
}

export default ComponentWithProps;