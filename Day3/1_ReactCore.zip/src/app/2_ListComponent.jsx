import React, { Component } from 'react';
import DataTable from './common/DataTable';

class ListComponent extends Component {
    render() {
        var lItems = this.props.items.map((item, index) => {
            return <li className="list-group-item" key={index}>{item.name}</li>
        });

        return (
            <ul className="list-group">
                {lItems}
            </ul>
        );
    }
}


class ListRoot extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: [
                { id: 1, name: "Manish" },
                { id: 2, name: "Abhijeet" },
                { id: 3, name: "Ramakant" },
                { id: 4, name: "Subodh" },
                { id: 5, name: "Abhishek" }
            ]
        };
    }

    render() {
        return (
            <div>
                {/* <ListComponent items={this.state.employees} /> */}
                <DataTable items={this.state.employees}>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NAME</th>
                            <th>DESIGNATION</th>
                        </tr>
                    </thead>
                </DataTable>
            </div>
        );
    }
}

export default ListRoot;