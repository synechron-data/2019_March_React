const aHelper = {
    getPosts: function (successCallback, errorCallback) {
        var url = "https://jsonplaceholder.typicode.com/posts";
        $.getJSON(url).done(data => { 
            successCallback(data);
        }).fail(err => { 
            errorCallback("Some Error, Contact Admin...");
        });
    }
};

export default aHelper;