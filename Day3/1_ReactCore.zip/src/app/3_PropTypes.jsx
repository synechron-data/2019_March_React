import React, { Component } from 'react';
import PropTypes from 'prop-types';

class PTComponent extends Component {
    render() {
        var n = this.props.name.toUpperCase();

        return (
            <div>
                <h2 className="text-info">Hello, {n}</h2>
                <h2 className="text-info">Age is, {this.props.age}</h2>
            </div>
        );
    }
}

PTComponent.propTypes = {
    name: PropTypes.string.isRequired,
    age: function (props, propName, componentName) {
        if (!props[propName]) {
            return new Error(componentName + " ---- " + propName + ", must be provided.");
        }
        if (props[propName] < 30) {
            return new Error(componentName + " ---- " + propName + ", must be greater than 30.");
        }
    }
}

class PTRoot extends Component {
    render() {
        return (
            <div>
                <PTComponent name={10} />
            </div>
        );
    }
}

export default PTRoot;