import React from 'react';
import CalculatorAssignment from './1_CalculatorAssignment';
import ListRoot from './2_ListComponent';
import PTRoot from './3_PropTypes';
import Parent from './4_LifeCycleMethods';
import AjaxComponent from './5_AjaxComponent';
import ErrorHandler from './common/ErrorHandler';

class RootComponent extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <CalculatorAssignment /> */}
                    {/* <ListRoot/> */}
                    {/* <PTRoot/> */}
                    {/* <Parent/> */}
                    {/* <AjaxComponent/> */}
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;