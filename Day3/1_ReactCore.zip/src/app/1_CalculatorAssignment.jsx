import React, { Component } from 'react';

class CalculatorOne extends Component {
    constructor(props) {
        super(props);
        this.state = { data: { t1: 0, t2: 0 }, result: 0 };
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleSubmit(e) {
        e.preventDefault();
        this.setState({ result: parseInt(this.refs.t1.value) + parseInt(this.refs.t2.value) });
    }

    render() {
        return (
            <form className="form-horizontal" onSubmit={this.handleSubmit} >
                <fieldset>
                    <legend>Calculator Assignment</legend>
                    <div className="form-group">
                        <label className="control-label col-sm-2" htmlFor="t1">Number One</label>
                        <div className="col-sm-6">
                            <input type="text" className="form-control" defaultValue={this.state.data.t1}
                                id="t1" ref="t1" />
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-2" htmlFor="t2">Number Two</label>
                        <div className="col-sm-6">
                            <input type="text" className="form-control" defaultValue={this.state.data.t2}
                                id="t2" ref="t2" />
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="col-sm-6 col-sm-offset-2">
                            <h3>Result: {this.state.result}</h3>
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="col-sm-offset-2 col-sm-3">
                            <button type="submit" className="btn btn-success btn-block">Add</button>
                        </div>
                        <div className="col-sm-3">
                            <button type="reset" className="btn btn-primary btn-block">Reset</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        );
    }
}

class CalculatorTwo extends Component {
    constructor(props) {
        super(props);
        this.state = { data: { t1: 0, t2: 0 }, result: 0 };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange1 = this.handleChange1.bind(this);
        this.handleChange2 = this.handleChange2.bind(this);
    }

    handleSubmit(e) {
        e.preventDefault();
        this.setState({ result: parseInt(this.state.data.t1) + parseInt(this.state.data.t2) });
    }

    handleChange1(e) {
        // var obj = Object.assign({}, this.state.data);
        var obj = { ...this.state.data };
        obj.t1 = e.target.value;
        this.setState({ data: obj });
    }

    handleChange2(e) {
        // var obj = Object.assign({}, this.state.data);
        var obj = { ...this.state.data };
        obj.t2 = e.target.value;
        this.setState({ data: obj });
    }

    render() {
        return (
            <form className="form-horizontal" onSubmit={this.handleSubmit} >
                <fieldset>
                    <legend>Calculator Assignment</legend>
                    <div className="form-group">
                        <label className="control-label col-sm-2" htmlFor="t1">Number One</label>
                        <div className="col-sm-6">
                            <input type="text" className="form-control" value={this.state.data.t1}
                                id="t1" onChange={this.handleChange1} />
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-2" htmlFor="t2">Number Two</label>
                        <div className="col-sm-6">
                            <input type="text" className="form-control" value={this.state.data.t2}
                                id="t2" onChange={this.handleChange2} />
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="col-sm-6 col-sm-offset-2">
                            <h3>Result: {this.state.result}</h3>
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="col-sm-offset-2 col-sm-3">
                            <button type="submit" className="btn btn-success btn-block">Add</button>
                        </div>
                        <div className="col-sm-3">
                            <button type="reset" className="btn btn-primary btn-block">Reset</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        );
    }
}

class CalculatorThree extends Component {
    constructor(props) {
        super(props);
        this.state = { data: { t1: 0, t2: 0 }, result: 0 };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleSubmit(e) {
        e.preventDefault();
        this.setState({ result: parseInt(this.state.data.t1) + parseInt(this.state.data.t2) });
    }

    handleChange(e) {
        const field = e.target.id;
        var obj = { ...this.state.data };
        obj[field] = e.target.value;
        this.setState({ data: obj });
    }

    render() {
        return (
            <form className="form-horizontal" onSubmit={this.handleSubmit} >
                <fieldset>
                    <legend>Calculator Assignment</legend>
                    <div className="form-group">
                        <label className="control-label col-sm-2" htmlFor="t1">Number One</label>
                        <div className="col-sm-6">
                            <input type="text" className="form-control" value={this.state.data.t1}
                                id="t1" onChange={this.handleChange} />
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-2" htmlFor="t2">Number Two</label>
                        <div className="col-sm-6">
                            <input type="text" className="form-control" value={this.state.data.t2}
                                id="t2" onChange={this.handleChange} />
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="col-sm-6 col-sm-offset-2">
                            <h3>Result: {this.state.result}</h3>
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="col-sm-offset-2 col-sm-3">
                            <button type="submit" className="btn btn-success btn-block">Add</button>
                        </div>
                        <div className="col-sm-3">
                            <button type="reset" className="btn btn-primary btn-block">Reset</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        );
    }
}

class TextInput extends Component {
    render() {
        return (
            <div className="form-group">
                <label className="control-label col-sm-2" htmlFor={this.props.name}>{this.props.label}</label>
                <div className="col-sm-6">
                    <input type="text" className="form-control"
                        value={this.props.value}
                        id={this.props.name}
                        name={this.props.name} onChange={this.props.onChange} />
                </div>
            </div>
        );
    }
}

class CalculatorFour extends Component {
    constructor(props) {
        super(props);
        this.state = { data: { t1: 0, t2: 0 }, result: 0 };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleSubmit(e) {
        e.preventDefault();
        this.setState({ result: parseInt(this.state.data.t1) + parseInt(this.state.data.t2) });
    }

    handleChange(e) {
        const field = e.target.id;
        var obj = { ...this.state.data };
        obj[field] = e.target.value;
        this.setState({ data: obj });
    }

    render() {
        return (
            <form className="form-horizontal" onSubmit={this.handleSubmit} >
                <fieldset>
                    <legend>Calculator Assignment</legend>

                    <TextInput label={"Number One"} name={"t1"} onChange={this.handleChange}
                        value={this.state.data.t1} />

                    <TextInput label={"Number Two"} name={"t2"} onChange={this.handleChange}
                        value={this.state.data.t2} />

                    <div className="form-group">
                        <div className="col-sm-6 col-sm-offset-2">
                            <h3>Result: {this.state.result}</h3>
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="col-sm-offset-2 col-sm-3">
                            <button type="submit" className="btn btn-success btn-block">Add</button>
                        </div>
                        <div className="col-sm-3">
                            <button type="reset" className="btn btn-primary btn-block">Reset</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        );
    }
}

class CalculatorAssignment extends Component {
    render() {
        return (
            <div>
                {/* <CalculatorOne /> */}
                {/* <CalculatorTwo /> */}
                {/* <CalculatorThree /> */}
                <CalculatorFour />
            </div>
        );
    }
}

export default CalculatorAssignment;