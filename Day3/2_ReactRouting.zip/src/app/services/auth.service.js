export const authenticator = {
    isAuthenticated: false,

    authenticate: function (uname, pwd, loginSuccess) {

    },

    getToken: function () {

    },

    logout: function () {

    }
}