import React, { Component } from 'react';

class AdminComponent extends Component {
    render() {
        return (
            <div>
                <h1 className="text-success">Welcome Admin!</h1>
            </div>
        );
    }
}

export default AdminComponent;