import React, { Component } from 'react';
import { Switch, Route, Redirect } from "react-router-dom";
import HomeComponent from './home/HomeComponent';
import AboutComponent from './about/AboutComponent';
import AdminComponent from './admin/AdminComponent';
import ProductsComponent from './products/ProductsComponent';
import LoginComponent from './login/LoginComponent';
import { authenticator } from './services/auth.service';

const SecuredRoute = ({ component: Component, ...args }) => {
    return <Route {...args} render={
        props => authenticator.isAuthenticated === true ? <Component {...props} /> :
            <Redirect to={{ pathname: '/login', state: { from: props.location } }} />
    } />
};

export default (
    <Switch>
        <Route exact path="/" component={HomeComponent} />
        <Route path="/about" component={AboutComponent} />
        <Route path="/products" component={ProductsComponent} />
        <Route path="/login" component={LoginComponent} />
        <SecuredRoute path="/admin" component={AdminComponent} />
        <Route path="**" render={() => (
            <article>
                <h1 className="text-danger">Component Not Found</h1>
                <p className="text-danger">Route is not configured...</p>
            </article>
        )} />
    </Switch>
);