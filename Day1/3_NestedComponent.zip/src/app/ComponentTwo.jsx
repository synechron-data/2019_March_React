import React from 'react';

class ComponentTwo extends React.Component {
    render() {
        return (
            <h1>Hello from Component Two!</h1>
        );
    }
}

export default ComponentTwo;