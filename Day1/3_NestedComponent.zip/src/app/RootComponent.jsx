import React from 'react';

import ComponentOne from "./ComponentOne";
import ComponentTwo from "./ComponentTwo";

class RootComponent extends React.Component {
    render() {
        return (
            <div>
                <h1>Hello from Root Component</h1>
                <ComponentOne/>
                <ComponentTwo/>
            </div>
        );
    }
}

export default RootComponent;