import React from 'react';

class ComponentOne extends React.Component {
    render() {
        return (
            <h1>Hello from Component One!</h1>
        );
    }
}

export default ComponentOne;