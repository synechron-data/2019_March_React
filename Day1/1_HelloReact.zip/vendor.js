import 'react';
import 'react-dom';

// Other Vendor Files like jQuery, Bootstrap, ChartJS