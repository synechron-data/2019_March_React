import React from 'react';

class ComponentOne extends React.Component {
    render() {
        return (
            <h2 className="text-warning">Hello from Component One!</h2>
        );
    }
}

export default ComponentOne;