const url = 'http://localhost:8000/api/authenticate';

export const authenticator = {
    isAuthenticated: false,

    authenticate: function (uname, pwd, loginSuccess) {
        var data = `username=${uname}&password=${pwd}`;

        let fData = {
            method: "POST",
            headers: {
                "content-type": "application/x-www-form-urlencoded"
            },
            body: data
        };

        fetch(url, fData).then((res) => {
            res.json().then((jdata) => {
                window.sessionStorage.setItem('tk', jdata.token);
                this.isAuthenticated = jdata.success;
                loginSuccess();
            });
        });
    },

    getToken: function () {
        return window.sessionStorage.getItem('tk');
    },

    logout: function () {
        window.sessionStorage.clear();
        this.isAuthenticated = false;
    }
}