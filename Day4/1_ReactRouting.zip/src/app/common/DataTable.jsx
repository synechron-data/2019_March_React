import React, { Component } from 'react';

class Th extends Component {
    render() {
        var thArr = new Array();

        for (const key in this.props.item) {
            thArr.push(key);
        }

        var ths = thArr.map((item, index) => {
            return <th key={index}>{item.toUpperCase()}</th>
        });

        return (
            <tr>
                {ths}
            </tr>
        );
    }
}


class Td extends Component {
    render() {
        return (
            <td>
                {this.props.data}
            </td>
        );
    }
}

class Tr extends Component {
    render() {
        var tds = new Array();
        var item = this.props.item;

        for (const key in item) {
            var d = item[key];
            tds.push(<Td data={d} key={d + key} />);
        }

        return (
            <tr>
                {tds}
            </tr>
        );
    }
}

class TBody extends Component {
    render() {
        var trs = this.props.items.map((item, index) => {
            return <Tr item={item} key={index} />
        });

        return (
            <tbody>
                {trs}
            </tbody>
        );
    }
}



class DataTable extends Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null, errorInfo: null };
    }

    render() {
        if (this.props.items) {
            var item = this.props.items[0];
            var Ths = <Th item={item} />
            var tBody = <TBody items={this.props.items} />
        }

        // if(this.state.hasError){
        //     return <h1 className="text-danger">Error Rending Table!</h1>
        // }
        return (
            <div>
                <h3 className="text-success">DataTable Component</h3>
                <table className="table">
                    <thead>
                        {Ths}
                    </thead>
                    {/* {this.props.children} */}
                    {tBody}
                </table>
            </div>
        );
    }

    // componentDidCatch(error, info) {
    //     this.setState({
    //         hasError: true, error: error, errorInfo: info
    //     });
    // }
}

export default DataTable;