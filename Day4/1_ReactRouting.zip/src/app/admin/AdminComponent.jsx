import React, { Component } from 'react';
import { authenticator } from '../services/auth.service';

class AdminComponent extends Component {
    render() {
        return (
            <div>
                <h1 className="text-success">Welcome Admin!</h1>
            </div>
        );
    }

    componentWillUnmount(){
        authenticator.logout();
    }
}

export default AdminComponent;